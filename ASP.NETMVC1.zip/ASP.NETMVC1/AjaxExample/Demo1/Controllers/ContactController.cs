﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Demo1.Models;

namespace Demo1.Controllers
{
    [HandleError]
    public class ContactController : Controller
    {
        // GET: Contact
        //[HandleError(View="Error.cshtml")]
        [HandleError]
        public ActionResult Index()
        {
            //Models.MyDataContext.ContactList
            return View();
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Contact cnt )
        {
            if (ModelState.IsValid)
            {
                MyDataContext.ContactList.Add(cnt);
                return RedirectToAction("Index");
            }

            else
                return View(); 
        }


        [HttpGet]
        public ActionResult Edit(int id)
        {
            Contact cntObj = MyDataContext.ContactList.FindAll(item => item.Id == id).First();
            return View(cntObj);
        }

        [HttpPost]
        public ActionResult Edit(Contact UpdatedCnt)
        {
            Contact Obj = MyDataContext.ContactList.FindAll(item => item.Id == UpdatedCnt.Id).First();
            Obj.Name = UpdatedCnt.Name;
            Obj.Mobile =UpdatedCnt.Mobile;
            Obj.Email = UpdatedCnt.Email;
            
            return RedirectToAction("Index");
        }

        public ActionResult Details(int id)
        {
            Models.Contact Obj = Models.MyDataContext.ContactList.Find(cnt => cnt.Id == id);
            return View(Obj);
        }


        public ActionResult Delete(int id)
        {
            MyDataContext.ContactList.RemoveAll(item => item.Id == id);
            return RedirectToAction("Index");
        }
    }
}