﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Demo1.Models
{
    public class Contact
    {
        public int Id { get; set; }

        [Required(ErrorMessage="Name Required")]
        public string Name { get; set; }

        [Display(Name="Phone Number")]
        public string Mobile { get; set; }
        
        [Required(ErrorMessage="Email Required")]
        [DataType(DataType.EmailAddress,ErrorMessage="Invalid Email")]
        public string Email { get; set; }

        //[Required(ErrorMessage="Age Required")]
        //[Range(minimum:15,maximum:40)]
        //public int Age { get; set; }
    }
}