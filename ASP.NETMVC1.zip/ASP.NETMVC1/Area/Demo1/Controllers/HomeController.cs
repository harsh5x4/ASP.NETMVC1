﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Demo1.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        
        public ViewResult Index()
        {
            return View();
        }

        //public string Index()
        //{
        //    return "<h1>Hello</h1>";
        //}

        //public string ContactUs()
        //{
        //    return "<h2>Contact Admin</h2>";
        //}

        public ActionResult ContactUS()
        {
            return View();
        }
    }
}