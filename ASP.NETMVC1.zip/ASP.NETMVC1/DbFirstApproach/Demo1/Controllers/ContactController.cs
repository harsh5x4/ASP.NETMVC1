﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Demo1.Controllers
{
    //[HandleError]
    public class ContactController : Controller
    {
        public ActionResult Index()
        {
            dbEntitiesConnections DB = new dbEntitiesConnections();

            return View(DB.Contacts_138222);
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Contacts_138222 cnt)
        {
            dbEntitiesConnections DB = new dbEntitiesConnections();
            DB.Contacts_138222.Add(cnt);
            DB.SaveChanges();
            return RedirectToAction("Index"); 
        }

        public ActionResult Delete(int id)
        {
            dbEntitiesConnections DB = new dbEntitiesConnections();
            DB.Contacts_138222.First(item => item.Id == id);
            DB.Contacts_138222.Remove(DB.Contacts_138222.First(item => item.Id == id));
            DB.SaveChanges();
            //return RedirectToAction("Index");
            return View();
        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            dbEntitiesConnections DB = new dbEntitiesConnections();
            return View(DB.Contacts_138222.First(item => item.Id == id));
        }

        [HttpPost]
        public ActionResult Edit(Contacts_138222 cnt)
        {
            dbEntitiesConnections DB = new dbEntitiesConnections();
            Contacts_138222 Obj = DB.Contacts_138222.First(item => item.Id == cnt.Id);
            Obj.Name = cnt.Name;
            Obj.Mobile = cnt.Mobile;
            Obj.Email = cnt.Email;
            DB.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult Details(int id)
        {
            dbEntitiesConnections DB = new dbEntitiesConnections();
           
            return View( DB.Contacts_138222.First(item => item.Id == id));
        }
    }
}